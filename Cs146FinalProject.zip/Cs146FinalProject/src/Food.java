
public class Food {
	String name;
	int calories;

	Food(String name, int calories) {
		this.name = name;
		this.calories = calories;
	}

	public String getName(String name) {
		return this.name;
	}

	public int getCalories(int calories) {
		return this.calories;
	}
}
